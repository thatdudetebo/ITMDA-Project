// Entity types mirroring the ERD in Deliverable 3, section 7.1.
// Keep these in sync with src/db/schema.ts.

export interface UserProfile {
  UserID: number;
  Name: string | null;
  Email: string | null;
}

export interface StudyMaterial {
  MaterialID: number;
  UserID: number;
  ModuleCode: string | null;
  FileName: string;
  FilePath: string;
  UploadDate: string;
}

export interface MaterialChunk {
  ChunkID: number;
  MaterialID: number;
  ChunkIndex: number;
  ExtractedText: string;
  /** Float32 vector stored as a BLOB. Null until the chunk has been embedded. */
  VectorEmbedding: Uint8Array | null;
}

export interface RevisionDeck {
  DeckID: number;
  MaterialID: number;
  DeckName: string;
}

export interface Flashcard {
  CardID: number;
  DeckID: number;
  Question: string;
  Answer: string;
  MasteryLevel: number;
}

/** History category used by Generate Summary, Ask Questions, and Generate Flashcards actions. */
export type GenerationHistoryTask = 'summary' | 'questions' | 'flashcards' | 'freeform';

/** Result payloads accepted by createGenerationHistory and returned when opening an item. */
export type GenerationHistoryResult =
  | { kind: 'text'; text: string }
  | { kind: 'question-answer'; items: Array<{ question: string; answer: string }> }
  | {
      kind: 'flashcards';
      deckName: string;
      cards: Array<{ question: string; answer: string }>;
    };

/** Lightweight fields shown in a history row before its saved result is loaded. */
export interface GenerationHistoryPreview {
  HistoryID: number;
  MaterialID: number;
  MaterialName: string;
  TaskType: GenerationHistoryTask;
  Prompt: string;
  GeneratedDate: string;
}

/** Full history row returned when a user opens an entry. */
export interface GenerationHistoryItem extends GenerationHistoryPreview {
  Result: GenerationHistoryResult;
}

/** A chunk returned by retrieval, with its similarity score. */
export interface RetrievedChunk extends MaterialChunk {
  similarity: number;
}
